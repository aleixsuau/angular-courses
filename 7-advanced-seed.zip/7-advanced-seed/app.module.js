angular
    .module('myApp', ['ui.router']);